<?php
class MyMod extends CI_Model {

/*=================================================================
	model login
==================================================================*/
function login_authen($username, $password){
		$this->db->select('*');
		$this->db->where('user', $username);
		$this->db->where('password', $password);
		$this->db->from('useradmin');
		$query = $this->db->get();
			if ($query->num_rows() == 1) {
				return true;
			}
			else{
				return false;
			}	
	}
	function authen_user($username){
		$this->db->select('authen');
		$this->db->where('user', $username);
		$this->db->from('useradmin');
		$query = $this->db->get();
		return $query->result_array();
	}

	function wrong_password($username, $value){ //update nilai authentication
		$this->db->set('authen', $value);
		$this->db->where("user", $username);
		$this->db->update('useradmin');
	}
}

?>