		<!-- Start Footer Section
		========================================== -->
		<footer id="footer" class="bg-one">
			<div class="container">
			    <div class="row wow fadeInUp" data-wow-duration="500ms">
					<div class="col-lg-12">
						
						<!-- Footer Social Links -->
						<div class="social-icon">
							<ul>
								<li><a href="#"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
								<li><a href="#"><i class="fa fa-youtube"></i></a></li>
								<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
								<li><a href="#"><i class="fa fa-dribbble"></i></a></li>
								<li><a href="#"><i class="fa fa-pinterest"></i></a></li>
							</ul>
						</div>
						<!--/. End Footer Social Links -->

						<!-- copyright -->
						<div class="copyright text-center">
							<img src="<?php echo base_url(); ?>/asset/img/logo-meghna.png" alt="Meghna" /> <br />
							<p>Copyright &copy; 2014. All Rights Reserved.</p>
						</div>
						<!-- /copyright -->
						
					</div> <!-- end col lg 12 -->
				</div> <!-- end row -->
			</div> <!-- end container -->
		</footer> <!-- end footer -->
		
		<!-- Back to Top
		============================== -->
		<a href="#" id="scrollUp"><i class="fa fa-angle-up fa-2x"></i></a>
		
		<!-- end Footer Area
		========================================== -->
		
		<!-- 
		Essential Scripts
		=====================================-->
		
		<!-- Main jQuery -->
		<script src="<?php echo base_url(); ?>/asset/js/jquery-1.12.2.min.js"></script>
		<!-- Bootstrap 3.1 -->
		<script src="<?php echo base_url(); ?>/asset/js/bootstrap.min.js"></script>
		<!-- Back to Top -->
		<script src="<?php echo base_url(); ?>/asset/js/jquery.scrollUp.min.js"></script>
		<script src="<?php echo base_url(); ?>/asset/js/classie.js"></script>
		<!-- Owl Carousel -->
		<script src="<?php echo base_url(); ?>/asset/js/owl.carousel.min.js"></script>
		<!-- Custom Scrollbar -->
		<script src="<?php echo base_url(); ?>/asset/js/jquery.nicescroll.min.js"></script>
		<!-- jQuery Easing -->
		<script src="<?php echo base_url(); ?>/asset/js/jquery.easing-1.3.pack.js"></script>
		<!-- wow.min Script -->
		<script src="<?php echo base_url(); ?>/asset/js/wow.min.js"></script>
		<!-- For video responsive -->
		<script src="<?php echo base_url(); ?>/asset/js/jquery.fitvids.js"></script>
		<!-- Custom js -->
		<script src="<?php echo base_url(); ?>/asset/js/custom.js"></script>

    </body>
</html>