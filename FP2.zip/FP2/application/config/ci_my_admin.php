<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

$config['ci_my_admin_template_dir'] = ""; // you need this line
$config['ci_my_admin_template_dir_public'] = $config['ci_my_admin_template_dir'] . "public/themes/default/";
$config['ci_my_admin_template_dir_admin'] = $config['ci_my_admin_template_dir'] . "admin/themes/default/";
$config['ci_my_admin_template_dir_welcome'] = $config['ci_my_admin_template_dir'] . "welcome/themes/default/";
?>